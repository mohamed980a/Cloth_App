import 'package:cloyhapp/features/Prodect/presentation/views/Widgets/prodect_body.dart';
import 'package:flutter/material.dart';

class ProdectScreen extends StatelessWidget {
  const ProdectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ProdectBody();
  }
}
