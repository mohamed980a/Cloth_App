class SubCategory {
  SubCategory();

  factory SubCategory.fromJson(Map<String, dynamic> json) {
    // TODO: implement fromJson
    throw UnimplementedError('SubCategory.fromJson($json) is not implemented');
  }

  Map<String, dynamic> toJson() {
    // TODO: implement toJson
    throw UnimplementedError();
  }
}
