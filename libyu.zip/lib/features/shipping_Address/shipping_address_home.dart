import 'package:cloyhapp/features/shipping_Address/shipping_address_body.dart';
import 'package:flutter/material.dart';

class shippingAddressHome extends StatelessWidget {
  const shippingAddressHome({super.key});

  @override
  Widget build(BuildContext context) {
    return const ShippingAddressBody();
  }
}
