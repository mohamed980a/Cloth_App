// import 'package:cloyhapp/features/Catalog/presentation/views/widgets/listview_horizontal_item.dart';
// import 'package:flutter/material.dart';
//
// class ListviewHorizontal extends StatelessWidget {
//   const ListviewHorizontal({super.key});
//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       height: 30,
//       child: ListView.builder(
//         scrollDirection: Axis.horizontal,
//         itemBuilder: (context, index) {
//           return SubCategoriesList();
//         },
//         itemCount: 90,
//       ),
//     );
//   }
// }
