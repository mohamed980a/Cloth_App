// wishlist_cubit.dart
import 'package:cloyhapp/cubit/addwislist_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../core/repo/repo.dart';
import 'wishlist_state.dart';

class WishlistAddCubit extends Cubit<WishlistAddState> {
  final AddWishlistRepository repository;

  WishlistAddCubit(this.repository) : super(WishlistAddInitial());

  Future<void> addProductToWishlistMoh(String productId) async {
    emit(WishlistAddLoading());
    try {
      await repository.addProductToWishlist(productId);
      emit(WishlistAddSuccess());
    } catch (e) {
      emit(WishlistAddError(e.toString()));
    }
  }
}
