import 'package:equatable/equatable.dart';

abstract class AddWishlistState {}

class AddWishlistInitial extends AddWishlistState {}

class AddWishlistLoading extends AddWishlistState {}

class AddWishlistSuccess extends AddWishlistState {}

class AddWishlistError extends AddWishlistState {
  final String message;

  AddWishlistError(this.message);
  @override
  List<Object?> get props => [message];
}

// wishlist_state.dart

abstract class WishlistAddState extends Equatable {
  @override
  List<Object?> get props => [];
}

class WishlistAddInitial extends WishlistAddState {}

class WishlistAddLoading extends WishlistAddState {}

class WishlistAddSuccess extends WishlistAddState {}

class WishlistAddError extends WishlistAddState {
  final String message;
  WishlistAddError(this.message);

  @override
  List<Object?> get props => [message];
}
