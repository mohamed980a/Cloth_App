class AppImages {
  static const String logo = 'assets/images/logosplash.png';
  static const String splash = 'assets/images/Splash_screen.png';
  static const String onBoarding1 = 'assets/images/onboarding1.png';
  static const String onBoarding2 = 'assets/images/onboarding2.png';
  static const String onBoarding3 = 'assets/images/onboarding3.png';


}