class AppTexts{

  static const String title1='Welcome to Courses';
  static const String title2='Now learn Outside \n    the Class';
  static const String title3='Approved  Certificate';

  static const String description1='Welcome as you learn a world \n changing skill to get a better job.';
  static const String description2='Giving education more flexible .';
  static const String description3='Start learning and get certified after \n your training to get a lucrative job';

}