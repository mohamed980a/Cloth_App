bool isLoggedInUser = false;

class SharedPrefKeys {
  static const String userToken = 'token';
}
