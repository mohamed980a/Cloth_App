import 'package:flutter/material.dart';
import 'package:cloyhapp/features/Favorite/presentation/views/widgets/Fav_listview_vertical_image.dart';

class FavListviewVerticalContainer extends StatelessWidget {
  final String brand;
  final String title;
  final String color;
  final String size;
  final String price;
  final int rating;
  final String reviews;

  const FavListviewVerticalContainer({
    super.key,
    required this.brand,
    required this.title,
    required this.color,
    required this.size,
    required this.price,
    required this.rating,
    required this.reviews,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: 390,
            height: 116,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(color: Colors.grey.shade300, blurRadius: 5)
              ],
            ),
            child: Row(
              children: [
                const FavListviewVerticalImage(),
                Padding(
                  padding: const EdgeInsets.only(left: 15, top: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(brand,
                              style: const TextStyle(
                                  fontSize: 11, color: Color(0xff9B9B9B))),
                          const SizedBox(width: 210),
                          const Icon(Icons.close,
                              color: Colors.black, size: 20),
                        ],
                      ),
                      Text(
                        title,
                        style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Color:",
                              style: TextStyle(
                                  fontSize: 11, color: Color(0xff9B9B9B))),
                          const SizedBox(width: 5),
                          Text(color,
                              style: const TextStyle(
                                  fontSize: 11, color: Colors.black)),
                          const SizedBox(width: 20),
                          const Text("Size:",
                              style: TextStyle(
                                  fontSize: 11, color: Color(0xff9B9B9B))),
                          const SizedBox(width: 5),
                          Text(size,
                              style: const TextStyle(
                                  fontSize: 11, color: Colors.black)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "$price\$",
                            style: const TextStyle(
                                fontSize: 14,
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(width: 50),
                          ...List.generate(
                            rating,
                            (index) => const Icon(Icons.star_rate_rounded,
                                color: Color(0xffFFBA49), size: 15),
                          ),
                          Text("($reviews)",
                              style: const TextStyle(
                                  fontSize: 11, color: Color(0xff9B9B9B))),
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 85, left: 350),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.purple[900],
              ),
              child: const Icon(Icons.shopping_bag_outlined,
                  color: Colors.white, size: 22),
            ),
          ),
        ],
      ),
    );
  }
}
