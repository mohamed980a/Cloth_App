// // import 'package:cloyhapp/features/Auth/data/model/wishlist.dart';
// // import 'package:equatable/equatable.dart';
// // import '../data/model_favorites.dart';
// //
// // abstract class WishlistStateM extends Equatable {
// //   @override
// //   List<Object?> get props => [];
// // }
// //
// // class WishlistMInitial extends WishlistStateM {}
// //
// // class WishlistMLoading extends WishlistStateM {}
// //
// // class WishlistMLoaded extends WishlistStateM {
// //   final List<WishlistResponse> wishlist;
// //
// //   WishlistMLoaded(this.wishlist);
// //
// //   @override
// //   List<Object?> get props => [wishlist];
// // }
// //
// // class WishlistMError extends WishlistStateM {
// //   final String message;
// //
// //   WishlistMError(this.message);
// //
// //   @override
// //   List<Object?> get props => [message];
// // }
//
//
// import '../data/model_favorites.dart';
//
// abstract class MWishlistState {}
//
// class MWishlistInitial extends MWishlistState {}
//
// class MWishlistLoading extends MWishlistState {}
//
// class MWishlistSuccess extends MWishlistState {
//   final AddFavorite response;
//
//   MWishlistSuccess(this.response);
// }
//
// class MWishlistError extends MWishlistState {
//   final String message;
//
//   MWishlistError(this.message);
// }


// wishlist_state.dart
import '../data/model_favorites.dart';

abstract class MMWishlistState {}

class MMWishlistInitial extends MMWishlistState {}

class MMWishlistLoading extends MMWishlistState {}

class MMWishlistAddedSuccess extends MMWishlistState {
  final AddFavorite response;
  MMWishlistAddedSuccess(this.response);
}

class MMWishlistLoaded extends MMWishlistState {
  final AddFavorite wishlist;
  MMWishlistLoaded(this.wishlist);
}

class MMWishlistError extends MMWishlistState {
  final String message;
  MMWishlistError(this.message);
}
