// // import 'package:cloyhapp/features/Auth/data/model/wishlist.dart';
// // import 'package:cloyhapp/features/Favorite/data/model_favorites.dart';
// // import 'package:flutter_bloc/flutter_bloc.dart';
// // import '../../../core/repo/repo.dart';
// // import '../../../cubit/wishlist_state.dart';
// // import '../data/repo_favorite.dart';
// // import 'wishlist_state.dart';
// //
// // class WishlistCubit extends Cubit<WishlistState> {
// //   final WishlistRepositoryMoist repository;
// //
// //   WishlistCubit(this.repository) : super(WishlistInitial());
// //
// //   void fetchWishlist() async {
// //     emit(WishlistLoading());
// //     try {
// //       final response = await repository.getWishlist();
// //       emit(WishlistLoaded(response.data.wishlist as WishlistResponse));
// //     } catch (e) {
// //       emit(WishlistError('Failed to load wishlist'));
// //     }
// //   }
// //
// //   void addToWishlist(String productId) async {
// //     try {
// //       await repository.addToWishlist(productId);
// //       fetchWishlist();
// //     } catch (e) {
// //       emit(WishlistError('Failed to add to wishlist'));
// //     }
// //   }
// //
// //   void removeFromWishlist(String id) async {
// //     try {
// //       await repository.deleteFromWishlist(id);
// //       fetchWishlist();
// //     } catch (e) {
// //       emit(WishlistError('Failed to remove from wishlist'));
// //     }
// //   }
// // }
//
// import 'package:cloyhapp/features/Favorite/data/model_favorites.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import '../data/repo_favorite.dart';
// import 'wishlist_state.dart';
//
// class MWishlistCubit extends Cubit<MWishlistState> {
//   final MMWishlistRepository repository;
//
//   MWishlistCubit(this.repository) : super(MWishlistInitial());
//
//   Future<void> addToWishlist(String productId) async {
//     emit(MWishlistLoading());
//     try {
//       final result = await repository.addProductToWishlist(productId);
//       emit(MWishlistSuccess(result as AddFavorite));
//     } catch (e) {
//       emit(MWishlistError(e.toString()));
//     }
//   }
// }

// wishlist_cubit.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import '../data/repo_favorite.dart';
import 'wishlist_state.dart';

class MMWishlistCubit extends Cubit<MMWishlistState> {
  final MMWishlistRepository repository;

  MMWishlistCubit(this.repository) : super(MMWishlistInitial());

  void addToWishlist(String productId, String token) async {
    emit(MMWishlistLoading());
    try {
      final response = await repository.addProductToWishlist(productId, token);
      emit(MMWishlistAddedSuccess(response));
      fetchWishlist(token); // refresh wishlist after adding
    } catch (e) {
      emit(MMWishlistError(e.toString()));
    }
  }

  void fetchWishlist(String token) async {
    emit(MMWishlistLoading());
    try {
      final response = await repository.fetchWishlist(token);
      emit(MMWishlistLoaded(response));
    } catch (e) {
      emit(MMWishlistError(e.toString()));
    }
  }
}
