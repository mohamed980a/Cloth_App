// class WishlistItem {
//   final String id;
//   final String productId;
//
//   WishlistItem({required this.id, required this.productId});
//
//   factory WishlistItem.fromJson(Map<String, dynamic> json) {
//     return WishlistItem(
//       id: json['_id'],
//       productId: json['productId'],
//     );
//   }
// }
//
// class WishlistResponse {
//   final String status;
//   final String message;
//   final List<WishlistItem> wishlist;
//
//   WishlistResponse({
//     required this.status,
//     required this.message,
//     required this.wishlist,
//   });
//
//   factory WishlistResponse.fromJson(Map<String, dynamic> json) {
//     final List<WishlistItem> wishlistItems = (json['data']?['wishlist'] ?? [])
//         .map<WishlistItem>((item) => WishlistItem.fromJson(item))
//         .toList();
//
//     return WishlistResponse(
//       status: json['status'],
//       message: json['message'],
//       wishlist: wishlistItems,
//     );
//   }
// }

class AddFavorite {
  String? status;
  String? message;
  Data? data;

  AddFavorite({this.status, this.message, this.data});

  AddFavorite.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> result = {};
    result['status'] = status;
    result['message'] = message;
    if (data != null) {
      result['data'] = data!.toJson();
    }
    return result;
  }
}

class Data {
  List<dynamic>? wishlist;

  Data({this.wishlist});

  Data.fromJson(Map<String, dynamic> json) {
    wishlist = json['wishlist'] ?? [];
  }

  Map<String, dynamic> toJson() {
    return {
      'wishlist': wishlist,
    };
  }
}
