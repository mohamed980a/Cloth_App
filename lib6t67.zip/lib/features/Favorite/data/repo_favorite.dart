// // import 'package:cloyhapp/core/Network/api_service.dart';
// //
// // import '../../Auth/data/model/wishlist.dart';
// //
// //
// // class WishlistRepositoryMoist {
// //   final LoginApi api;
// //
// //   WishlistRepositoryMoist(this.api);
// //
// //   Future<WishlistResponse> getWishlist() => api.getWishlist();
// //
// //   Future<WishlistResponse> addToWishlist(String productId) =>
// //       api.addToWishlist({"productId": productId});
// //
// //   Future<WishlistResponse> deleteFromWishlist(String id) =>
// //       api.deleteFromWishlist(id);
// // }
//
//
// import 'package:cloyhapp/core/Network/api_service.dart';
// import 'package:cloyhapp/features/Auth/data/model/wishlist.dart';
//
// import 'model_favorites.dart';
//
// class WishlistRepositoryM {
//   final LoginApi apiService;
//
//   WishlistRepositoryM(this.apiService);
//
//   Future<WishlistResponse> addProductToWishlist(String productId) async {
//     return await apiService.addToWishlist({
//       'productId': productId,
//     });
//   }
// }

import 'package:cloyhapp/core/Network/api_service.dart';

import 'model_favorites.dart';

class MMWishlistRepository {
  final LoginApi api;

  MMWishlistRepository(this.api);

  Future<AddFavorite> addProductToWishlist(String productId, String token) {
    return api.addToWishlist({'productId': productId}, 'Bearer $token');
  }

  Future<AddFavorite> fetchWishlist(String token) {
    return api.getWishlist('Bearer $token');
  }
}
