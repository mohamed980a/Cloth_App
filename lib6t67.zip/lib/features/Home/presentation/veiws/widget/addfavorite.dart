// // import 'package:flutter/material.dart';
// // import 'package:flutter_bloc/flutter_bloc.dart';
// //
// // import '../../../../../core/repo/repo.dart';
// // import '../../../../Favorite/data/repo_favorite.dart';
// // import '../../../../Favorite/logic/wishlist_cubit.dart';
// //
// // class Addfavorite extends StatelessWidget {
// //   const Addfavorite({super.key});
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return BlocProvider(
// //       create: (context) => MWishlistCubit(WishlistRepositoryM(apiService)),
// //       child: Builder(
// //         builder: (context) => IconButton(
// //           onPressed: () {
// //             final cubit = context.read<MWishlistCubit>();
// //             cubit.addToWishlist("67f1531f4ce63fa48934b72b");
// //           },
// //           icon:  Icon(Icons.favorite_border, color: Colors.grey),
// //           // child: Text("Add to Wishlist"),
// //         ),
// //       ),
// //     );;
// //   }
// // }
//
//
// import 'package:cloyhapp/core/Network/api_service.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
//
// import '../../../../Favorite/data/repo_favorite.dart';
// import '../../../../Favorite/logic/wishlist_cubit.dart';
// import '../../../../Favorite/logic/wishlist_state.dart';
//
// class AddFavorites extends StatelessWidget {
//   const AddFavorites({super.key,});
//   @override
//   Widget build(BuildContext context) {
//     return BlocConsumer<MMWishlistCubit, MMWishlistState>(
//         listener: (context, state) {
//           if (state is MMWishlistLoading) {
//             ScaffoldMessenger.of(context).showSnackBar(
//               SnackBar(content: Text("Added to wishlist")),
//             );
//           } else if (state is MMWishlistError) {
//             ScaffoldMessenger.of(context).showSnackBar(
//               SnackBar(content: Text("Error: ${state.message}")),
//             );
//           }
//         },
//         builder: (context, state) {
//           return IconButton(
//             onPressed: () {
//               context.read<MMWishlistCubit>().addToWishlist("67f1531f4ce63fa48934b72b");
//             },
//             icon: Icon(
//               Icons.favorite_border,
//               color: Colors.grey,
//             ),
//           );
//         },
//     );
//   }
// }
