// // wishlist_repository.dart
// import 'package:cloyhapp/core/Network/api_service.dart';
// import 'package:dio/dio.dart';
//
// class WishlistAddRepository {
//   final LoginApi apiService;
//
//   WishlistAddRepository(this.apiService);
//
//   Future<void> addProductToWishlist(String productId) async {
//     final body = {"productId": productId};
//     await apiService.addToWishlist(body);
//   }
// }
