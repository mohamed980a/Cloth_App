// part of 'getproductscategory_cubit.dart';
//
// @immutable
// abstract class GetproductscategoryState {}
//
// class GetproductscategoryInitial extends GetproductscategoryState {}
//
// class GetproductscategoryLoading extends GetproductscategoryState {}
//
// class GetproductscategoryLoaded extends GetproductscategoryState {
//   final List<NewProduct> products;
//   GetproductscategoryLoaded(this.products);
// }
//
// class GetproductscategoryError extends GetproductscategoryState {
//   final String message;
//   GetproductscategoryError(this.message);
// }
