// import 'package:cloyhapp/features/Catalog/presentation/views/widgets/listview_vertical_item.dart';
// import 'package:flutter/material.dart';
//
// class ListviewVertical extends StatelessWidget {
//   final String token;
//   final String categoryId;
//   final String subcategoryId;
//
//   const ListviewVertical({
//     super.key,
//     required this.token,
//     required this.categoryId,
//     required this.subcategoryId,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return ListView.builder(
//       shrinkWrap: true,
//       physics: const NeverScrollableScrollPhysics(),
//       padding: EdgeInsets.zero,
//       itemCount: 1,
//       itemBuilder: (context, index) {
//         return ListviewVerticalItem(
//           subcategoryId: subcategoryId,
//           token: token,
//           categoryId: categoryId,
//         );
//       },
//     );
//   }
// }
