import 'package:cloyhapp/cubit/get_new_products_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import '../../../../../cubit/addwislist_cubit.dart';
import '../../../../../cubit/addwislist_state.dart';

class ListViewNewHorizontal extends StatelessWidget {
  final int limit = 10;
  final int page = 1;

  const ListViewNewHorizontal({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ProductCubit, ProductState>(
      builder: (context, state) {
        if (state is ProductLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is ProductLoaded) {
          final products = state.newProduct.data?.products;

          if (products == null || products.isEmpty) {
            return const Center(child: Text("لا توجد منتجات حالياً"));
          }

          return SizedBox(
            height: 325,
            width: double.infinity,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];

                return SizedBox(
                  width: 240,
                  height: 300,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Card(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Image + NEW Badge + Favorite Icon
                          Stack(
                            children: [
                              ClipRRect(
                                borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                                child: Image.network(
                                  product.imgCover ?? "", // Replace with your image asset
                                  // height: 250,
                                  // width: double.infinity,
                                  height: 194,
                                  width: 164,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              // NEW Label
                              Positioned(
                                top: 12,
                                left: 5,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.black,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child:  Text(
                                    "NEW",
                                    style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 12),
                                  ),
                                ),
                              ),
                              // Heart Icon
                              Positioned(
                                bottom: 12,
                                right: 12,
                                child: Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration:  BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle,
                                  ),
                                  child: IconButton(icon:  Icon(Icons.favorite_border, color: Colors.grey), onPressed: () {
                                    // Navigate to product details screen
                                    state is WishlistAddLoading
                                        ? null
                                        : () => context.read<WishlistAddCubit>().addProductToWishlistMoh('${product.id}');
                                    child: state is WishlistAddLoading
                                        ? CircularProgressIndicator()
                                        : Icon(Icons.favorite_border, color: Colors.grey);


                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //     builder: (context) => FavScreen(productId: product.sId),
                                    //   ),
                                    // );
                                  },),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          // Star rating
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Row(
                              children: [
                                RatingBarIndicator(
                                  rating: 0,
                                  itemBuilder: (context, index) => const Icon(Icons.star, color: Colors.grey),
                                  itemCount: 5,
                                  itemSize: 16,
                                  unratedColor: Colors.grey.shade300,
                                ),
                                const SizedBox(width: 2),
                                Text("${product.ratingsAverage ?? 0}", style: TextStyle(color: Colors.black54)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 2),
                          // Brand & Name
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("${product.sId}", style: TextStyle(color: Colors.black54)),
                                Text(product.name ?? '', style:  TextStyle(overflow: TextOverflow.ellipsis, fontSize: 16, fontWeight: FontWeight.bold),),
                                Text( "${product.price?.toStringAsFixed(2) ?? ''} EGP", style: TextStyle(fontSize: 16, color: Colors.black,fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),


                  ),
                );
              },
            ),
          );
        } else if (state is ProductError) {
          return Center(child: Text("خطأ: ${state.message}"));
        }

        return const Center(child: Text("لا توجد بيانات."));
      },
    );
  }
}

//
// SizedBox(
// height: 300,
// width: double.infinity,
// child: SizedBox(
// height: 320,
// child: ListView.builder(
// scrollDirection: Axis.horizontal,
// itemCount: 5,
// itemBuilder: (context, index) {
// return Padding(
// padding: const EdgeInsets.only(right: 10),
// child: SizedBox(
// width: 160,
// child: ListViewNewItems(),
// ),
// );
// },
// ),
// ),
// );
