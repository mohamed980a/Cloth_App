import 'dart:ui';

abstract class StaticColors {
  static const Color util_color = Color(0xff570091);
  static const Color star_color = Color(0xffFFBA49);
}
